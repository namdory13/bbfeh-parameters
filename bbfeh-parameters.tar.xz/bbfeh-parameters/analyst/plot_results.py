#!/usr/bin/env python3
import matplotlib
matplotlib.use('Agg')
import csv, os
import matplotlib.pyplot as plt

os.makedirs("plots", exist_ok=True)

rows = []
with open("results/summary.csv") as f:
    reader = csv.DictReader(f)
    for r in reader:
        rows.append(r)

def f(row, key):
    return float(row[key])

def select(prefix):
    return [r for r in rows if r["name"].startswith(prefix)]

def bar_plot(data, xkey, ykey, title, outfile):
    labels = [r["name"] for r in data]
    vals = [f(r, ykey) for r in data]
    plt.figure(figsize=(9,4))
    plt.bar(labels, vals)
    plt.title(title)
    plt.ylabel(ykey)
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(outfile)
    plt.close()
    print("Created", outfile)

alpha = [r for r in rows if r["name"] in ["alpha_low", "baseline", "alpha_high"]]
segment = [r for r in rows if r["name"] in ["L_small", "baseline", "L_large"]]
delay = [r for r in rows if r["name"] in ["delay_close", "baseline", "delay_far"]]

bar_plot(alpha, "name", "SNR", "Effect of alpha on SNR", "plots/alpha_vs_snr.png")
bar_plot(alpha, "name", "peak_gap", "Effect of alpha on cepstrum peak gap", "plots/alpha_vs_peakgap.png")
bar_plot(segment, "name", "payload_bps", "Effect of L on payload capacity", "plots/L_vs_payload.png")
bar_plot(delay, "name", "peak_gap", "Effect of delay distance on peak separation", "plots/delay_vs_peakgap.png")
bar_plot(rows, "name", "BER", "BER comparison of all experiments", "plots/ber_comparison.png")
