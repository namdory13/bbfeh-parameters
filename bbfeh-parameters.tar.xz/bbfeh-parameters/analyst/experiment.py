#!/usr/bin/env python3
import matplotlib
matplotlib.use('Agg')
import argparse, os, csv
import numpy as np
import soundfile as sf
import matplotlib.pyplot as plt

def snr_db(x, y):
    noise = y - x
    return 10 * np.log10((np.sum(x*x) + 1e-12) / (np.sum(noise*noise) + 1e-12))

def add_bbfeh(seg, bit, alpha, d0, d1):
    out = np.copy(seg)
    a = alpha / 4.0
    if bit == "0":
        pairs = [(d0, a), (d1, -a)]
    else:
        pairs = [(d1, a), (d0, -a)]
    for d, amp in pairs:
        if d < len(seg):
            out[d:] += amp * seg[:-d]
            out[:-d] += amp * seg[d:]
    return out

def extract_bits(y, L, d0, d1, nbits):
    bits = []
    peaks = []
    for i in range(nbits):
        seg = y[i*L:(i+1)*L]
        spec = np.fft.fft(seg)
        cep = np.real(np.fft.ifft(np.log(np.abs(spec) + 1e-12)))
        c0, c1 = cep[d0], cep[d1]
        bits.append("0" if c0 > c1 else "1")
        peaks.append((abs(c0), abs(c1), abs(c0-c1)))
    return "".join(bits), peaks

def ber(a, b):
    n = min(len(a), len(b))
    if n == 0:
        return 100.0
    return 100.0 * sum(a[i] != b[i] for i in range(n)) / n

def plot_cepstrum(y, L, d0, d1, name):
    seg = y[0:L]
    spec = np.fft.fft(seg)
    cep = np.real(np.fft.ifft(np.log(np.abs(spec) + 1e-12)))
    os.makedirs("plots", exist_ok=True)
    plt.figure(figsize=(9,4))
    plt.plot(cep[:600])
    plt.axvline(d0, linestyle="--", label=f"d0={d0}")
    plt.axvline(d1, linestyle="--", label=f"d1={d1}")
    plt.title(f"Cepstrum peak visualization - {name}")
    plt.xlabel("Delay / quefrency sample")
    plt.ylabel("Cepstrum value")
    plt.legend()
    plt.tight_layout()
    plt.savefig(f"plots/{name}_cepstrum.png")
    plt.close()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--alpha", type=float, required=True)
    p.add_argument("--L", type=int, required=True)
    p.add_argument("--d0", type=int, required=True)
    p.add_argument("--d1", type=int, required=True)
    p.add_argument("--name", required=True)
    args = p.parse_args()

    message = "1011001110"
    x, sr = sf.read("audio_samples/cover.wav")
    if x.ndim > 1:
        x = x[:,0]

    y = np.copy(x)
    nbits = min(len(message), len(x)//args.L)

    for i in range(nbits):
        s, e = i*args.L, (i+1)*args.L
        y[s:e] = add_bbfeh(x[s:e], message[i], args.alpha, args.d0, args.d1)

    os.makedirs("outputs", exist_ok=True)
    os.makedirs("results", exist_ok=True)

    outwav = f"outputs/{args.name}_stego.wav"
    sf.write(outwav, y, sr)

    recovered, peaks = extract_bits(y, args.L, args.d0, args.d1, nbits)
    peak_d0 = float(np.mean([p[0] for p in peaks]))
    peak_d1 = float(np.mean([p[1] for p in peaks]))
    peak_gap = float(np.mean([p[2] for p in peaks]))

    payload_bps = sr / args.L
    snr = snr_db(x, y)
    b = ber(message[:nbits], recovered)

    csv_path = f"results/{args.name}.csv"
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["name","alpha","L","d0","d1","SNR","BER","payload_bps","peak_d0","peak_d1","peak_gap","message","recovered"])
        w.writerow([args.name,args.alpha,args.L,args.d0,args.d1,round(snr,4),round(b,4),round(payload_bps,4),peak_d0,peak_d1,peak_gap,message[:nbits],recovered])

    plot_cepstrum(y, args.L, args.d0, args.d1, args.name)

    print("="*60)
    print("BBFEH PARAMETER EXPERIMENT")
    print("="*60)
    print("Name:", args.name)
    print("alpha:", args.alpha)
    print("L:", args.L)
    print("d0:", args.d0, "d1:", args.d1)
    print("Output wav:", outwav)
    print("Result csv:", csv_path)
    print("Cepstrum plot:", f"plots/{args.name}_cepstrum.png")
    print("SNR:", round(snr,4), "dB")
    print("BER:", round(b,4), "%")
    print("Payload:", round(payload_bps,4), "bps")
    print("Recovered:", recovered)

if __name__ == "__main__":
    main()
