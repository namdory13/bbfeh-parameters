#!/usr/bin/env python3
import glob, csv, os

files = sorted(glob.glob("results/*.csv"))
rows = []
header = None

for fp in files:
    if fp.endswith("summary.csv"):
        continue
    with open(fp) as f:
        r = list(csv.reader(f))
        if len(r) >= 2:
            header = r[0]
            rows.append(r[1])

os.makedirs("results", exist_ok=True)

with open("results/summary.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(header)
    w.writerows(rows)

print("Created results/summary.csv")
print("Experiments:", len(rows))
for row in rows:
    print(row[0], "SNR=", row[5], "BER=", row[6], "Payload=", row[7], "PeakGap=", row[10])
